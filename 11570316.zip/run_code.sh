#!/bin/sh
python HW2_315_Kshvedov.py